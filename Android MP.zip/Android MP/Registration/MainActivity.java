package com.example.myapplication123456;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etName, etPassword, etConfirmPassword, etEmail;
    RadioGroup radioGroup;
    Button btnSubmit, btnReset, btnStart, btnStop;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI Elements
        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        etEmail = findViewById(R.id.etEmail);
        radioGroup = findViewById(R.id.radioGroup);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnReset = findViewById(R.id.btnReset);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        imageView = findViewById(R.id.imageView);

        // Submit Button Click
        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String password = etPassword.getText().toString();
            String confirmPassword = etConfirmPassword.getText().toString();
            String email = etEmail.getText().toString();
            int selectedId = radioGroup.getCheckedRadioButtonId();

            if (name.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty() || selectedId == -1) {
                Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(confirmPassword)) {
                Toast.makeText(MainActivity.this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
            } else {
                RadioButton selectedRadio = findViewById(selectedId);
                String gender = selectedRadio.getText().toString();
                Toast.makeText(MainActivity.this, "Registration Successful!\nName: " + name + "\nEmail: " + email + "\nGender: " + gender, Toast.LENGTH_LONG).show();
            }
        });

        // Reset Button Click
        btnReset.setOnClickListener(v -> {
            etName.setText("");
            etPassword.setText("");
            etConfirmPassword.setText("");
            etEmail.setText("");
            radioGroup.clearCheck();
            Toast.makeText(MainActivity.this, "Form Reset", Toast.LENGTH_SHORT).show();
        });

        // Start Button Click
        btnStart.setOnClickListener(v -> {
            imageView.setImageResource(R.drawable.img_1);
            Toast.makeText(MainActivity.this, "start button click", Toast.LENGTH_SHORT).show();
        });

        // Stop Button Click
        btnStop.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "stop button click", Toast.LENGTH_SHORT).show();
        });
    }
}